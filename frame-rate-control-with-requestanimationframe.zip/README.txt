A Pen created at CodePen.io. You can find this one at https://codepen.io/njmcode/pen/kmIpi.

 Using frame time deltas to ensure consistent motion speed and refresh rate regardless of how often requestAnimationFrame fires.  Needed for things like physics sims, game dev, etc.